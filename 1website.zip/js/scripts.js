// Add any JavaScript functionality here
console.log("Welcome to my professional personal website!");